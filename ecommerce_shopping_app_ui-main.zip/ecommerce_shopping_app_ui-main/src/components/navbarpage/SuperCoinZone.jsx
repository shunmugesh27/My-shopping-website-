
function SuperCoinZone() {
    document.title = "Super Coin Zone - Ecommerce Shopping App"
    return (
        <div className="h-screen">
            <br /><br />
            <h1 className="text-center text-2xl dark:text-white">Welcome To SuperCoinZone</h1>

        </div>
    )
}

export default SuperCoinZone
