
function GiftCardComp() {
    document.title = "Gift Cart - Ecommerce Shopping App"
    return (
        <div className="text-center h-screen">
            <h1 className="font-bold text-2xl dark:text-white">GiftCardComp page</h1>
        </div>
    )
}

export default GiftCardComp
