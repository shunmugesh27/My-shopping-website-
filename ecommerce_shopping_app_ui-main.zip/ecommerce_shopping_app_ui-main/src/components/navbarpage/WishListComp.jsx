
function WishListComp() {
    document.title = "Wish List - Ecommerce Shopping App"
    return (
        <div className="text-center h-screen">
            <h1 className="font-bold text-2xl dark:text-white">WishListComp page</h1>
        </div>
    )
}

export default WishListComp
