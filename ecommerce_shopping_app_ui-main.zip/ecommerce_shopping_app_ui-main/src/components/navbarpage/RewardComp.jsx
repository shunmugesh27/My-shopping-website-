
function RewardComp() {
    document.title = "Reward- Ecommerce Shopping App"
    return (
        <div className="text-center h-screen">
            <h1 className="font-bold text-2xl dark:text-white">RewardComp page</h1>
        </div>
    )
}

export default RewardComp
