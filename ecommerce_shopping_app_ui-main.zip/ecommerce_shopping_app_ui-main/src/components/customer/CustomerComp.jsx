
function CustomerComp() {
    document.title = "Customer - Ecommerce Shopping App"
    return (
        <div className="text-center h-screen">
            <h1 className="font-bold text-2xl dark:text-white">Customer Component page</h1>
        </div>
    )
}

export default CustomerComp
