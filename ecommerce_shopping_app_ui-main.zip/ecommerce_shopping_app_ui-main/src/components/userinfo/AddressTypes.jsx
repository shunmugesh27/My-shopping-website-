export let addressType = [
    "OFFICE",
    "SHOP",
    "HOME",
    "INDUSTRY",
    "OTHER"
]