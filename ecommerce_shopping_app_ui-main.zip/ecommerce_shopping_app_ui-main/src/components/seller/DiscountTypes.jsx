export const discounts = [
    // Discount Methods
    "FLAT",
    "PERCENTAGE",

    // Seasonal Discounts
    "DIWALI",
    "NEWYEAR",

    // Special Event Discounts
    "NEW",
    "SPECIAL"
]